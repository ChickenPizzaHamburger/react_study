export default function Test1(){
    return(
      <div style={{
        height: '300px',
        border: '3px solid blue'
      }}>
        <h1>연습1</h1>
      </div>
    )
  }