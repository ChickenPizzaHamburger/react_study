export default function Test2(){
    return(
      <div style={{
        height: '300px',
        border: '3px solid green'
      }}>
        <h1>연습2</h1>
      </div>
    )
  }